/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.railway_reservation;
/**
 *
 * @author hp
 */
public class Railway_Reservation {

    public static void main(String[] args) {
        MAIN my=new MAIN();
        my.setVisible(true);
        my.setSize(720,444);
    }
}
